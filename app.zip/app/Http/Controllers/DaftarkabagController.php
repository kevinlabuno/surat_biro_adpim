<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DaftarkabagController extends Controller
{
    public function index(){
    }
}
